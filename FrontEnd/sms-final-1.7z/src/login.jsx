import React from "react";

import "./login.css";
import Logo from "./logo.jfif";

function Login(props) {



  return (
    <div>
      <div className="login-container">
        <div className="login-wrapper">
          <div className="login-fields">
            <div>
              <img className="login-logo" src={Logo} alt="" />
              <h1 className="Login-heading,thicker">Login</h1>
            </div>
            <input
              type="text"
              placeholder="Username"
              className="username-input"
            />
            <input
              type="Password"
              placeholder="Password"
              className="password-input"
            />
            <select name="" id="" className="login-select">
              <option value="value">
                Select Status
              </option>
              <option value="admin">Admin</option>
              <option value="student">Student</option>
            </select>
            <button className="login-btn" onClick={props.loginHandler}>
              Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
