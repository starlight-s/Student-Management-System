import React, { useState, Fragment } from "react";
import { nanoid } from "nanoid";
import "./module.css";
import data from "./datamodule.json";
import ReadOnlyRow from "./ReadOnlyRow";
import EditableRow from "./EditableRow";

const Moduleadmin = () => {
  const [contacts, setContacts] = useState(data);
  const [addFormData, setAddFormData] = useState({
    date: "",
    course: "",
    module: "",
    file: "",
  });

  const [editFormData, setEditFormData] = useState({
    date: "",
    course: "",
    module: "",
    file: "",
  });

  const [editContactId, setEditContactId] = useState(null);

  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;
    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

  const handleEditFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...editFormData };
    newFormData[fieldName] = fieldValue;

    setEditFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newContact = {
      id: nanoid(),
      date: addFormData.date,
      course: addFormData.course,
      module: addFormData.module,
      file: addFormData.file,
    };

    const newContacts = [...contacts, newContact];
    setContacts(newContacts);
  };

  const handleEditFormSubmit = (event) => {
    event.preventDefault();

    const editedContact = {
      id: editContactId,
      date: editFormData.date,
      course: editFormData.course,
      module: editFormData.module,
      file: editFormData.file,
    };

    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === editContactId);

    newContacts[index] = editedContact;

    setContacts(newContacts);
    setEditContactId(null);
  };

  const handleEditClick = (event, contact) => {
    event.preventDefault();
    setEditContactId(contact.id);

    const formValues = {
      date: contact.date,
      course: contact.course,
      module: contact.module,
      file: contact.file,
    };

    setEditFormData(formValues);
  };

  const handleCancelClick = () => {
    setEditContactId(null);
  };

  const handleDeleteClick = (contactId) => {
    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === contactId);

    newContacts.splice(index, 1);

    setContacts(newContacts);
  };
  // ***********************body*********************
  return (
    <body className="adminmodule_body">
      <div className="adminmodule_container">
        <h2 className="adminmodule_heading">Module Performance</h2>
        <form onSubmit={handleAddFormSubmit} className="admin_form">
          <select
            required="required"
            name="course"
            onChange={handleAddFormChange}
            className="adminmodule_select"
          >
            <option value="" disabled selected>
              Select Course
            </option>
            <option value="PG-DAC">PG-DAC</option>
            <option value="PG-DBDA">PG-DBDA</option>
            <option value="PG-DESD">PG-DESD</option>
          </select>
          <select
            required="required"
            name="module"
            onChange={handleAddFormChange}
            className="adminmodule_select"
          >
            <option value="" disabled selected>
              Select Course
            </option>
            <option value="Java">Java</option>
            <option value="Advance java">Advance java</option>
            <option value="DBMS">DBMS</option>
          </select>
          <input
            className="adminmodule_input"
            type="date"
            name="date"
            required="required"
            placeholder="Enter a Date"
            onChange={handleAddFormChange}
          />
          <input
            className="adminmodule_input"
            type="file"
            name="file"
            required="required"
            onChange={handleAddFormChange}
          />
          <button className="adminmodule_buttonadd" type="submit">
            Add
          </button>
        </form>
        {/*----------------- table------------------*/}
        <form onSubmit={handleEditFormSubmit}>
          <table className="adminmodule_table">
            <tr>
              <th className="adminmodule_head">Date</th>
              <th className="adminmodule_head">Course</th>
              <th className="adminmodule_head">Module</th>
              <th className="adminmodule_head">File</th>
              <th className="adminmodule_head">Actions</th>
            </tr>

            <tbody className="adminmodule_body">
              {contacts.map((contact) => (
                <Fragment>
                  {editContactId === contact.id ? (
                    <EditableRow
                      editFormData={editFormData}
                      handleEditFormChange={handleEditFormChange}
                      handleCancelClick={handleCancelClick}
                    />
                  ) : (
                    <ReadOnlyRow
                      contact={contact}
                      handleEditClick={handleEditClick}
                      handleDeleteClick={handleDeleteClick}
                    />
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </form>
      </div>
    </body>
  );
};

export default Moduleadmin;
