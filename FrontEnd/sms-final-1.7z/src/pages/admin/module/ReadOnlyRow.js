import React from "react";
import "./module.css";
const ReadOnlyRow = ({ contact, handleEditClick, handleDeleteClick }) => {
  return (
    <tr className="adminnotice_row">
      <td>{contact.date}</td>
      <td>{contact.course}</td>
      <td>{contact.module}</td>
      <td>{contact.file}</td>

      <td>
        <button
          className="adminnotice_buttoneditbody"
          type="button"
          onClick={(event) => handleEditClick(event, contact)}
        >
          Edit
        </button>
        <button
          className="adminnotice_buttondeletebody"
          type="button"
          onClick={() => handleDeleteClick(contact.id)}
        >
          Delete
        </button>
      </td>
    </tr>
  );
};

export default ReadOnlyRow;
