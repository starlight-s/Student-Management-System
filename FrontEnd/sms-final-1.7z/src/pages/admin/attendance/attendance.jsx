import React, { Component } from "react";
import "./attendance.css";

class AdminAttendance extends Component {
  constructor() {
    super();
    this.state = {
      DDL1: [],
      DDL2: [],
      selectddl1: "",
    };
  }

  componentDidMount() {
    this.setState({
      DDL1: [
        {
          Course: "PG-DAC",
          DDL2: ["core_java", "advance_java", "Database_technology"],
        },
        { Course: "PG-DBDA", DDL2: ["DBDAsub1", "DBDAsub1", "DBDAsub1"] },
        { Course: "PG-DESD", DDL2: ["DESDsub1", "DESDsub1", "DESDsub1"] },
        { Course: "PG-DITIS", DDL2: ["DITISsub1", "DITISsub1", "DITISsub1"] },
      ],
    });
  }

  selectChange(e) {
    this.setState({ selectddl1: e.target.value });
    this.setState({
      DDL2: this.state.DDL1.find((x) => x.Course === e.target.value).DDL2,
    });
  }

  render() {
    return (
      <div className="Attendancea_container">
        <div className="Attendancea_wrapper">
          <select
            className="Attendancea_select"
            value={this.state.selectddl1}
            onChange={this.selectChange.bind(this)}
          >
            <option value="">---select---</option>
            {this.state.DDL1.map((x) => {
              return <option>{x.Course}</option>;
            })}
          </select>
          <br />
          <select className="Attendancea_select" Course="" id="">
            <option value="" selected disabled>
              ----------Module---------
            </option>
            {this.state.DDL2.map((x) => {
              return <option>{x}</option>;
            })}
          </select>
          <br />
          <input type="file" name="" id="" className="Attendanceabtninput" />
          <br />
          <button className="Attendanceabtnupload">Upload</button>
        </div>
      </div>
    );
  }
}

export default AdminAttendance;
