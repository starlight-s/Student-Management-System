import React from "react";
import "./module.css";

function Modulep() {
  const Data = [
    {
      name: "Core java",
      labmarks: "20",
      internalmarks: "35",
      cceemarks: "43",
      total: "200",
      moduledate: "2-12-1999",
      examdate: "5-10-2000",
    },
    {
      name: "Advance Java ",
      labmarks: "20",
      internalmarks: "32",
      cceemarks: "40",
      total: "200",
      moduledate: "2-12-1999",
      examdate: "5-10-2000",
    },
    {
      name: "Database technology",
      labmarks: "20",
      internalmarks: "32",
      cceemarks: "40",
      total: "200",
      moduledate: "2-12-1999",
      examdate: "5-10-2000",
    },
    {
      name: "ASP.NET ",
      labmarks: "20",
      internalmarks: "30",
      cceemarks: "40",
      total: "200",
      moduledate: "2-12-1999",
      examdate: "5-10-2000",
    },
    {
      name: " Operating System",
      labmarks: "20",
      internalmarks: "30",
      cceemarks: "40",
      total: "200",
      moduledate: "2-12-1999",
      examdate: "5-10-2000",
    },
  ];
  return (
    <>
      <div className="module_data">
        <div className="module_container">
          {Data.map((Module) => (
            <div className="module_wrapper">
              <div className="module_namewrapper">
                <h6 className="module_subjecthead">subject</h6>
                <h1 className="module_subjectname">{Module.name}</h1>
              </div>
              <div className="module_markswrapper">
                <div className="module_innerwrapper1">
                  <h4>Date</h4>
                  <h4>Exam Date</h4>
                  <hr />
                  <h4>Lab Exam Marks</h4>
                  <h4> Internal Marks</h4>
                  <h4> CCEE Marks</h4>
                  <hr />
                  <h4> Total Marks</h4>
                </div>
                <div className="module_innerwrapper1">
                  <h4 className="module_info">{Module.moduledate}</h4>
                  <h4 className="module_info">{Module.examdate}</h4>
                  <hr />
                  <h4 className="module_info">{Module.labmarks}</h4>
                  <h4 className="module_info">{Module.internalmarks}</h4>
                  <h4 className="module_info">{Module.cceemarks}</h4>
                  <hr />
                  <h4 className="module_info">{Module.total}</h4>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Modulep;
