import { useState } from "react";

import Calender from "./Calender";

import DateSelector from "./DateSelector";
import './attendance.css'

const attendanceData = [
  {
    prn: 1,
    attendance: [
      {
        date: new Date("2022/02/17"),
        present: true,
      },
      {
        date: new Date("2022/02/18"),
        present: false,
      },
      {
        date: new Date("2022/02/19"),
        present: true,
      },
      {
        date: new Date("2022/02/20"),
        present: true,
      },
      {
        date: new Date("2022/03/18"),
        present: true,
      },
      {
        date: new Date("2022/04/19"),
        present: false,
      },
    ],
  },
  {},
  {},
  {},
];

function Attendance() {
  const [date, setDate] = useState({});

  const dateHandler = (dateFromDateSelector) => {
    setDate(dateFromDateSelector);
    console.log("Date in App", dateFromDateSelector);
  };

  return (
    <div className="Attendance">
      <DateSelector dateHandler={dateHandler} />
      <Calender date={date} attendanceData={attendanceData} prn={1} />
    </div>
  );
}

export default Attendance;
