import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./component/navbar/navbar";
import Profile from "./pages/student/profile/profile";
import AdminProfile from "./pages/admin/profile/profile";
import AdminAttendance from "./pages/admin/attendance/attendance"
import Attendance from "./pages/student/attendance/attendance";
import Notice from "./pages/student/notice/notice";
import AdminNotice from "./pages/admin/notice/notice";
import Idcard from "./pages/student/idcard/id";
import Upload from "./pages/admin/updatedata/uplaod";
import Module from "./pages/student/module/module";
import AdminModule from "./pages/admin/module/module";
import Enquiry from "./pages/student/enquiry/enquiry";
import AdminEnquiry from "./pages/admin/enquiry/enquiry";
import Login from "./login"
const App = () => {

  const [isAdmin, setIsAdmin] = useState(false)
  const [isLogin, setIsLogin] = useState(false)

  useEffect(() => {
    setIsAdmin(localStorage.getItem('isAdmin') ? true : false)
  }, [])

  console.log(isAdmin)

  const loginHandler = () => {
    setIsLogin(true)
  }

  return (
    <>
      <div>
        <BrowserRouter>
          <Navbar isAdmin={isAdmin} isLogin={isLogin}/>
          <Routes>
            {!isLogin && <Route path="/" element={<Login loginHandler={loginHandler}/>} />}
            {(!isAdmin && isLogin) && <Route path="/" element={<Profile />}/>}
            {(isAdmin && isLogin) && <Route path="/" element={<AdminProfile />}/>}
            {!isAdmin && <Route path="/notice" element={<Notice />} /> }
            {isAdmin && <Route path="/notice" element={<AdminNotice />} /> }
            {isAdmin && <Route path="/attendance" element={<AdminAttendance />} /> }
            {!isAdmin && <Route path="/attendance" element={<Attendance />} /> }
            {!isAdmin && <Route path="/idcard" element={<Idcard />}/> }
            {!isAdmin && <Route path="/module" element={<Module /> } /> }
            {isAdmin && <Route path="/module" element={<AdminModule />} /> }
            {!isAdmin && <Route path="/enquiry" element={<Enquiry />} />}
            {isAdmin && <Route path="/enquiry" element={<AdminEnquiry />} />}
            {isAdmin && <Route path="/upload" element={<Upload />}/>}
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
};

export default App;
